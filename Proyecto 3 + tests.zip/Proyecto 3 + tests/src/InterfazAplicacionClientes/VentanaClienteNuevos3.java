package InterfazAplicacionClientes;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class VentanaClienteNuevos3 extends JFrame implements ActionListener{
	
	private String usuario;
	private String contrasena;
	private String nombre;
	private String fechaNacimiento;
	private String telefono;
	private String correo;
	
	private String numeroLicencia;
	private String paisExpedicion;
	private String fechaVencimiento;
	private String urlImagen;
	
	private String tipoTarjeta;
	private String numeroTarjeta;
	private String fechaVencimientoTarjeta;
	private String montoDisponible;
	
	private JTextField tipoTarjetaField;
	private JTextField numeroTarjetaField;
	private JTextField fechaVencimientoTarjetaField;
	private JTextField montoDisponibleTarjetaField;
	
	private JPanel todoPanel;
	private Color miVerde;
	
	private VentanaOpcionesNuevas ventanitaAparte;

	public VentanaClienteNuevos3(String usuario, String contrasena, String nombre, String fechaNacimiento, String telefono, String correo, String numeroLicencia, String paisExpedicion, String fechaVencimiento, String urlImagen) {
		this.usuario = usuario;
		this.contrasena = contrasena;
		this.nombre = nombre;
		this.fechaNacimiento = fechaNacimiento;
		this.telefono = telefono;
		this.correo = correo;
		this.numeroLicencia = numeroLicencia;
		this.paisExpedicion = paisExpedicion;
		this.fechaVencimiento = fechaVencimiento;
		this.urlImagen = urlImagen;
		
		miVerde = new Color(202,222,185);
		
		//Quiero un panel grande con MINIpaneles
		todoPanel = new JPanel(new BorderLayout());
		todoPanel.setBackground(Color.white);
		
		//Minipanel de arriba que es un BorderLayout
		JPanel panelArriba = new JPanel(new BorderLayout());
		panelArriba.setBackground(miVerde);
		panelArriba.setPreferredSize(new Dimension(800, 90));
		
		//Etiqueta del titulo centrada en un panel de BorderLayout
		JLabel etiquetaRapidos = new JLabel("Rápidos y Aletosos", JLabel.CENTER);
		etiquetaRapidos.setFont(new Font("Georgia", Font.BOLD, 40));
		panelArriba.add(etiquetaRapidos, BorderLayout.CENTER);
		
		//Minipanel de abajo que es un Border Layout
		JPanel panelAbajo = new JPanel(new BorderLayout());
		
		//Configuracion del boton de enviar
		JButton botonEnviar = new JButton("Enviar");
		botonEnviar.setFont(new Font("Georgia", Font.PLAIN, 16));
		botonEnviar.setForeground(Color.BLACK);
		botonEnviar.setBackground(miVerde);
		botonEnviar.setPreferredSize(new Dimension(40, 50));
		panelAbajo.add(botonEnviar, BorderLayout.CENTER);
		
		
		//Minipanel de la mitad que es un Border Layout
		JPanel panelMitad = new JPanel(new BorderLayout());
		panelMitad.setBackground(Color.white);
		
		
		//Lema de la empresa que va al norte en la mitad
		JLabel etiquetaLema = new JLabel("La carretera te llama, nosotros te equipamos", JLabel.CENTER);
		etiquetaLema.setFont(new Font("Georgia", Font.PLAIN, 30));
		panelMitad.add(etiquetaLema, BorderLayout.NORTH);
		
		
		//JPanel para ubicar con el menu y las cosas
		JPanel panelMensaje= new JPanel(new BorderLayout());
		
		//Instruccion
		JLabel etiquetaInstruccion = new JLabel("Ingrese la informacion de su tarjeta", JLabel.CENTER);
		etiquetaInstruccion.setFont(new Font("Georgia", Font.PLAIN, 20));
		
		//Opciones en un JPanel en Grid
				
		JPanel panelMenuInfoBasica = new JPanel(new GridLayout(5, 1));
		
		JLabel numeroTarjetaLabel = new JLabel("Numero de tarjeta");
		numeroTarjetaField = new JTextField(20);
		numeroTarjetaField.setMaximumSize(new Dimension(300, 70));
		JLabel tipoLabel = new JLabel("Tipo de tarjeta");
		tipoTarjetaField = new JTextField(20);
		tipoTarjetaField.setMaximumSize(new Dimension(300, 70));
		
		JLabel fechaVencimientoLabel = new JLabel("Fecha de vencimiento DD/MM/AAAA");
		fechaVencimientoTarjetaField = new JTextField(20);
		fechaVencimientoTarjetaField.setMaximumSize(new Dimension(300, 70));
		JLabel montoDisponibleLabel = new JLabel("Monto disponible");
		montoDisponibleTarjetaField = new JTextField(20);
		montoDisponibleTarjetaField.setMaximumSize(new Dimension(300, 70));
		
		//Fuentes
	
		numeroTarjetaLabel.setFont(new Font("Georgia", Font.BOLD, 20));

		tipoLabel.setFont(new Font("Georgia", Font.BOLD, 20));
		fechaVencimientoLabel.setFont(new Font("Georgia", Font.BOLD, 20));
		montoDisponibleLabel.setFont(new Font("Georgia", Font.BOLD, 20));
		//ActionListenerEnviar
		botonEnviar.setActionCommand("Enviar");
		botonEnviar.addActionListener(this);
		
		//Añadimos todo
		panelMensaje.setBackground(Color.white);
		panelMenuInfoBasica.setBackground(Color.white);
		panelMensaje.add(etiquetaInstruccion);
		panelMenuInfoBasica.add(numeroTarjetaLabel);
		panelMenuInfoBasica.add(numeroTarjetaField);
		panelMenuInfoBasica.add(tipoLabel);
		panelMenuInfoBasica.add(tipoTarjetaField);
		panelMenuInfoBasica.add(fechaVencimientoLabel);
		panelMenuInfoBasica.add(fechaVencimientoTarjetaField);
		panelMenuInfoBasica.add(montoDisponibleLabel);
		panelMenuInfoBasica.add(montoDisponibleTarjetaField);
	

		//ActionListenerEnviar
		botonEnviar.setActionCommand("Enviar");
		botonEnviar.addActionListener(this);

		
		panelMitad.add(panelMensaje, BorderLayout.CENTER);
		panelMitad.add(panelMenuInfoBasica, BorderLayout.SOUTH);
		
		todoPanel.add(panelArriba, BorderLayout.NORTH);
		todoPanel.add(panelMitad, BorderLayout.CENTER);
		todoPanel.add(panelAbajo, BorderLayout.SOUTH);

		
		//Agrega el panel con todos los minipaneles que acabo de crear a la ventana
		setContentPane(todoPanel);
		
		//Detiene la aplicación al cerrar la ventana
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Define el tamaño inicial de la ventana
		setSize(800, 500);
		setResizable(false);
		
		//Define el título de la ventana
		setTitle("Clientes nuevos");

		//Muestra la ventana
		setVisible(true);
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String grito = e.getActionCommand();
		tipoTarjeta = tipoTarjetaField.getText();
		numeroTarjeta = numeroTarjetaField.getText();
		fechaVencimientoTarjeta = fechaVencimientoTarjetaField.getText();
		montoDisponible = montoDisponibleTarjetaField.getText();
		
		if (grito.equals("Enviar")) {
			
			try {
				ventanitaAparte = new VentanaOpcionesNuevas(usuario, contrasena, nombre, correo, telefono, fechaNacimiento, numeroLicencia, paisExpedicion, fechaVencimiento, urlImagen, numeroTarjeta, tipoTarjeta, fechaVencimientoTarjeta, montoDisponible);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			this.dispose();
		}
	}

}
