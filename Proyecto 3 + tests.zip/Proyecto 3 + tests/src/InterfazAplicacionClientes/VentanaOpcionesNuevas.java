package InterfazAplicacionClientes;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import InterfazAplicacionClientes.VentanaReservaClientesNuevos;
import Programa.Empresa;

public class VentanaOpcionesNuevas extends JFrame implements ActionListener{
	
	private JPanel todoPanel;
	private Color miVerde;
	private ButtonGroup grupoAccion;
	private JRadioButton ConsultaBtn;
	private JRadioButton ReservaBtn;
	
	private String usuario;
	private String contrasena;
	private String nombre;
	private String correo;
	private String telefono;
	private String fechaNacimiento;
	
	private String numeroLicencia;
	private String paisExpedicion;
	private String fechaVencimiento;
	private String urlImagen;
	
	private String tipoTarjeta;
	private String numeroTarjeta;
	private String fechaVencimientoTarjeta;
	private String montoDisponible;
	
	private Empresa empresa;
	
	public VentanaOpcionesNuevas(String usuario, String contrasena, String nombre, String correo, String telefono, String fechaNacimiento, String numeroLicencia, String paisExpedicion, String fechaVenciminetoLicencia, String urlImagen, String numeroTarjeta, String tipoTarjeta, String fechaVencimientoTarjeta, String montoDisponible) throws IOException {
		
		this.empresa = new Empresa();
		
		this.usuario = usuario;
		this.contrasena = contrasena;
		this.nombre = nombre;
		this.correo = correo;
		this.telefono = telefono;
		this.fechaNacimiento = fechaNacimiento;
		this.numeroLicencia = numeroLicencia;
		this.paisExpedicion = paisExpedicion;
		this.fechaVencimiento = fechaVenciminetoLicencia;
		this.urlImagen = urlImagen;
		this.numeroTarjeta = numeroTarjeta;
		this.tipoTarjeta = tipoTarjeta;
		this.fechaVencimientoTarjeta = fechaVencimientoTarjeta;
		this.montoDisponible = montoDisponible;
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate fechaNacimientoDate = LocalDate.parse(this.fechaNacimiento, formatter);
		LocalDate fechaLicencia = LocalDate.parse(fechaVencimiento, formatter);
		LocalDate fechaTarjeta = LocalDate.parse(this.fechaVencimientoTarjeta, formatter);
		
		fechaNacimiento = fechaNacimientoDate.format(formatter);
		fechaVenciminetoLicencia = fechaLicencia.format(formatter);
		System.out.println(fechaVenciminetoLicencia);
		fechaVencimientoTarjeta = fechaTarjeta.format(formatter);
		
		empresa.getInventario().agregarCliente(nombre, usuario, contrasena, telefono, correo, Long.parseLong(numeroLicencia), paisExpedicion, fechaLicencia, urlImagen, Long.parseLong(numeroTarjeta), tipoTarjeta, fechaTarjeta, Double.parseDouble(montoDisponible), fechaNacimientoDate,fechaNacimiento , fechaVencimientoTarjeta, fechaVenciminetoLicencia);

		miVerde = new Color(202,222,185);
		
		//Quiero un panel grande con MINIpaneles
		todoPanel = new JPanel(new BorderLayout());
		todoPanel.setBackground(Color.white);
		
		//Minipanel de arriba que es un BorderLayout
		JPanel panelArriba = new JPanel(new BorderLayout());
		panelArriba.setBackground(miVerde);
		panelArriba.setPreferredSize(new Dimension(800, 90));
		
		//Etiqueta del titulo centrada en un panel de BorderLayout
		JLabel etiquetaRapidos = new JLabel("Rápidos y Aletosos", JLabel.CENTER);
		etiquetaRapidos.setFont(new Font("Georgia", Font.BOLD, 40));
		panelArriba.add(etiquetaRapidos, BorderLayout.CENTER);
		
		//Minipanel de abajo que es un Border Layout
		JPanel panelAbajo = new JPanel(new BorderLayout());
		
		//Configuracion del boton de enviar
		JButton botonEnviar = new JButton("Enviar");
		botonEnviar.setFont(new Font("Georgia", Font.PLAIN, 16));
		botonEnviar.setForeground(Color.BLACK);
		botonEnviar.setBackground(miVerde);
		botonEnviar.setPreferredSize(new Dimension(40, 50));
		panelAbajo.add(botonEnviar, BorderLayout.CENTER);
		
		
		//Minipanel de la mitad que es un Border Layout
		JPanel panelMitad = new JPanel(new BorderLayout());
		panelMitad.setBackground(Color.white);
		
		
		//Lema de la empresa que va al norte en la mitad
		JLabel etiquetaLema = new JLabel("La carretera te llama, nosotros te equipamos", JLabel.CENTER);
		etiquetaLema.setFont(new Font("Georgia", Font.PLAIN, 30));
		panelMitad.add(etiquetaLema, BorderLayout.NORTH);
		
		
		//JPanel para ubicar con el menu y las cosas
		JPanel panelMensaje= new JPanel(new BorderLayout());
		
		//Instruccion
		JLabel etiquetaInstruccion = new JLabel("Elije la acción a realizar", JLabel.CENTER);
		etiquetaInstruccion.setFont(new Font("Georgia", Font.PLAIN, 20));
		
		//Opciones en un JPanel en Grid
				
		JPanel panelMenu = new JPanel(new GridLayout(2, 1));
		
		//Solo una opcion -> creo grupo
		grupoAccion = new ButtonGroup();
		
		//Grupo de botones
		ConsultaBtn = new JRadioButton("Consultar disponibilidad");
		ReservaBtn = new JRadioButton("Reservar Vehiculo");
		
		ConsultaBtn.setBackground(Color.WHITE);
		ReservaBtn.setBackground(Color.WHITE);
	
		
		
		ConsultaBtn.setFont(new Font("Georgia", Font.PLAIN, 20));
		ReservaBtn.setFont(new Font("Georgia", Font.PLAIN, 20));

		
		//Solo un boton seleccionado en mi grupo
		grupoAccion.add(ConsultaBtn);
		grupoAccion.add(ReservaBtn);
	
		
		//ActionListenerEnviar
		botonEnviar.setActionCommand("Enviar");
		botonEnviar.addActionListener(this);
		
		//Añadimos todo
		panelMensaje.setBackground(Color.white);
		panelMensaje.add(etiquetaInstruccion, BorderLayout.NORTH);
		panelMenu.add(ConsultaBtn);
		panelMenu.add(ReservaBtn);

		
		panelMitad.add(panelMensaje, BorderLayout.CENTER);
		panelMitad.add(panelMenu, BorderLayout.SOUTH);
		
		todoPanel.add(panelArriba, BorderLayout.NORTH);
		todoPanel.add(panelMitad, BorderLayout.CENTER);
		todoPanel.add(panelAbajo, BorderLayout.SOUTH);

		
		//Agrega el panel con todos los minipaneles que acabo de crear a la ventana
		setContentPane(todoPanel);
		
		//Detiene la aplicación al cerrar la ventana
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Define el tamaño inicial de la ventana
		setSize(800, 350);
		setResizable(false);
		
		//Define el título de la ventana
		setTitle("Opciones Clientes Nuevos");

		//Muestra la ventana
		setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String grito = e.getActionCommand();
		if (grito.equals("Enviar")) {
			
			if (ConsultaBtn.isSelected()) {
				this.dispose();
				try {
					VentanaConsulta ventanaConsulta = new VentanaConsulta();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}else if (ReservaBtn.isSelected()) {
				this.dispose();
				try {
					VentanaReservaClientesNuevos ventanaReserva = new VentanaReservaClientesNuevos(usuario, nombre, telefono, correo, fechaNacimiento, Long.parseLong(numeroLicencia), paisExpedicion, urlImagen, fechaVencimiento, Long.parseLong(numeroTarjeta), tipoTarjeta, fechaVencimientoTarjeta);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			
			
		}
		
		
	}

}
