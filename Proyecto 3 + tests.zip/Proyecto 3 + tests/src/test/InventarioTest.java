package test;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;

import org.junit.Test;

import Programa.Categoria;
import Programa.Inventario;
import Programa.Vehiculo;

public class InventarioTest {

    @Test
    public void testAgregarVehiculo() {
        Inventario inventario = new Inventario();
        Categoria categoria  = Categoria("Sedán", 100.0, 80.0, 20.0, 15.0);
        Vehiculo vehiculo = new Vehiculo(
            Categoria.Grande, "ABC123", "Toyota", "Corolla", "Rojo",
            "Automático", 5, false, "Grande", 0.1
        );

        inventario.agregarVehiculo(vehiculo);

        assertTrue(inventario.agregarVehiculo(vehiculo));
    }
    
    @Test
    public void testEliminarVehiculo() {
        Inventario inventario = new Inventario();

        Vehiculo vehiculo = new Vehiculo(
            Categoria.Grande, "ABC123", "Toyota", "Corolla", "Rojo",
            "Automático", 5, false, "Grande", 0.1
        );

        assertFalse(inventario.eliminarVehiculo(vehiculo)); // Verifica que el vehículo no esté presente inicialmente

        inventario.agregarVehiculo(vehiculo); // Agrega el vehículo al inventario

        assertTrue(inventario.eliminarVehiculo(vehiculo)); // Verifica que el vehículo se haya eliminado
        assertEquals(0, inventario.obtenerCantidadVehiculos());
    }

    @Test
    public void testAgregarCliente() {
         Inventario inventario = new Inventario();
        assertNotNull(inventario.getClientes());
        assertEquals(0, inventario.getClientes().size());

        LicenciaConduccion licencia = new LicenciaConduccion(123456, "PaisLicencia", LocalDate.now().plusYears(1), "imagenLicencia");
        TarjetaCredito medioPago = new TarjetaCredito("TipoTarjeta", 987654321, LocalDate.now().plusYears(2), 1000.0);

        inventario.agregarCliente("usuario4", "contrasena4", "NombreCliente", "RolCliente", "123456789", "correo@cliente.com", LocalDate.now(), licencia, medioPago);

        assertEquals(1, inventario.getClientes().size());

        // Obtener el cliente recién agregado
        Cliente clienteAgregado = inventario.getClientes().get(0);

        // Verificar que los atributos del cliente coincidan con los valores proporcionados
        assertEquals("UsuarioCliente", clienteAgregado.getLogin());
        assertEquals("ContraseñaCliente", clienteAgregado.getPassword());
        assertEquals("NombreCliente", clienteAgregado.getNombre());
        assertEquals("RolCliente", clienteAgregado.getRol());
        assertEquals("123456789", clienteAgregado.getTelefono());
        assertEquals("correo@cliente.com", clienteAgregado.getCorreo());
        assertEquals(LocalDate.now().minusYears(25), clienteAgregado.getFechaNacimiento());

        // Verificar la licencia
        assertEquals(123456, clienteAgregado.getLicencia().getNumero());
        assertEquals("PaisLicencia", clienteAgregado.getLicencia().getPaisExpedicion());
        assertEquals(LocalDate.now().plusYears(1), clienteAgregado.getLicencia().getFechaVencimiento());
        assertEquals("imagenLicencia", clienteAgregado.getLicencia().getImagen());

        // Verificar el medio de pago
        assertEquals("TipoTarjeta", clienteAgregado.getMedioPago().getTipo());
        assertEquals(987654321, clienteAgregado.getMedioPago().getNumero());
        assertEquals(LocalDate.now().plusYears(2), clienteAgregado.getMedioPago().getFechaVencimiento());
        assertEquals(1000.0, clienteAgregado.getMedioPago().getMontoDisponible(), 0.001);
    }
    
    @Test
    public void testAgregarSede() {
        // Crear un objeto de la clase que contiene los métodos (Inventario en este caso)
        Inventario inventario = new Inventario();

        // Verificar que la lista de sedes esté inicialmente vacía
        assertNotNull(inventario.getSedes());
        assertEquals(0, inventario.getSedes().size());

        // Agregar una sede
        inventario.agregarSede("AdminNombre", "AdminUsuario", "AdminPassword", "SedeTest", "UbicacionTest");

        // Verificar que la lista de sedes ahora contenga exactamente una sede
        assertEquals(1, inventario.getSedes().size());

        // Obtener la sede recién agregada
        Sede sedeAgregada = inventario.getSedes().get(0);

        // Verificar que los atributos de la sede coincidan con los valores proporcionados
        assertEquals("SedeTest", sedeAgregada.getNombre());
        assertEquals("UbicacionTest", sedeAgregada.getUbicacion());

        // Verificar que la sede tenga un administrador local asignado
        assertNotNull(sedeAgregada.getAdminLocal());
        assertEquals("AdminNombre", sedeAgregada.getAdminLocal().getNombre());
        assertEquals("AdminUsuario", sedeAgregada.getAdminLocal().getLogin());
    }
    
    @Test
    public void testEliminarSede() {
        // Crear un objeto de la clase que contiene los métodos (Inventario en este caso)
        Inventario inventario = new Inventario();

        // Agregar una sede para probar la eliminación
        inventario.agregarSede("AdminEliminar", "UserEliminar", "PasswordEliminar", "SedeEliminar", "UbicacionEliminar");

        // Verificar que la lista de sedes contenga al menos una sede
        assertEquals(1, inventario.getSedes().size());

        // Obtener la sede a eliminar (en este caso, asumimos que hay al menos una sede)
        Sede sedeAEliminar = inventario.getSedes().get(0);

        // Eliminar la sede
        inventario.eliminarSede(sedeAEliminar);

        // Verificar que la lista de sedes esté vacía después de la eliminación
        assertEquals(0, inventario.getSedes().size());
    }
}
