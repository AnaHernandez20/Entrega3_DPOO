package test;

import static org.junit.Assert.*;

import org.junit.Test;

import Programa.Seguro;

public class SeguroTest {

    @Test
    public void testCrearSeguro() {
        Seguro seguro = new Seguro("SeguroPrueba", 50.0);
        assertNotNull(seguro);
        assertEquals("SeguroPrueba", seguro.getNombre());
        assertEquals(50.0, seguro.getTarifaDiaria(), 0.001);
    }

    @Test
    public void testModificarNombreSeguro() {
        Seguro seguro = new Seguro("SeguroOriginal", 75.0);
        seguro.setNombre("NuevoSeguro");
        assertEquals("NuevoSeguro", seguro.getNombre());
    }

    @Test
    public void testModificarTarifaDiariaSeguro() {
        Seguro seguro = new Seguro("SeguroOriginal", 75.0);
        seguro.setTarifaDiaria(90.0);
        assertEquals(90.0, seguro.getTarifaDiaria(), 0.001);
    }

    @Test
    public void testAccederNombreSeguro() {
        Seguro seguro = new Seguro("SeguroAcceso", 60.0);
        assertEquals("SeguroAcceso", seguro.getNombre());
    }

    @Test
    public void testAccederTarifaDiariaSeguro() {
        Seguro seguro = new Seguro("SeguroAcceso", 60.0);
        assertEquals(60.0, seguro.getTarifaDiaria(), 0.001);
    }
}