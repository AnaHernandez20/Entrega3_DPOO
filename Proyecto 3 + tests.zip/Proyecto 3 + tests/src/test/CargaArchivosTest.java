package test;
import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class CargaArchivosTest {
	@Test
    void cargarCategorias() {
        Inventario inventario = new Inventario();
        try {
            inventario.cargarCategorias("data/archivoCategorias.txt");
            assertNotNull(inventario.getCategorias());
            assertFalse(inventario.getCategorias().isEmpty());
        } catch (IOException e) {
            fail("Error en la carga de categorías: " + e.getMessage());
        }
    }

    @Test
    void cargarAdminsLocales() {
        Inventario inventario = new Inventario();
        try {
            inventario.cargarAdminsLocales("data/archivoAdminLocal.txt");
            assertNotNull(inventario.getAdministradoresLocales());
            assertFalse(inventario.getAdministradoresLocales().isEmpty());
        } catch (IOException e) {
            fail("Error en la carga de administradores locales: " + e.getMessage());
        }
    }

    @Test
    void cargarProductos() {
        Inventario inventario = new Inventario();
        try {
            inventario.cargarProductos("data/archivoProductos.txt");
            assertNotNull(inventario.getProductos());
            assertFalse(inventario.getProductos().isEmpty());
        } catch (IOException e) {
            fail("Error en la carga de productos: " + e.getMessage());
        }
    }

    @Test
    void cargarUsuarios() {
        Inventario inventario = new Inventario();
        try {
            inventario.cargarUsuarios("data/archivoUsuarios.txt");
            assertNotNull(inventario.getUsuarios());
            assertFalse(inventario.getUsuarios().isEmpty());
        } catch (IOException e) {
            fail("Error en la carga de usuarios: " + e.getMessage());
        }
    }

    @Test
    void cargarVentas() {
        Inventario inventario = new Inventario();
        try {
            inventario.cargarVentas("data/archivoVentas.txt");
            assertNotNull(inventario.getVentas());
            assertFalse(inventario.getVentas().isEmpty());
        } catch (IOException e) {
            fail("Error en la carga de ventas: " + e.getMessage());
        }
    }

    @Test
    void cargarCategoriaConArchivoInexistente() {
        Inventario inventario = new Inventario();
        assertThrows(IOException.class, () -> inventario.cargarCategorias("archivo_inexistente.txt"));
    }

    @Test
    void cargarCategoriaConFormatoInvalido() {
        Inventario inventario = new Inventario();
        assertThrows(NumberFormatException.class, () -> inventario.cargarCategorias("data/archivoCategorias_invalido.txt"));
    }

    @Test
    void cargarAdminLocalConArchivoInexistente() {
        Inventario inventario = new Inventario();
        assertThrows(IOException.class, () -> inventario.cargarAdminsLocales("archivo_inexistente.txt"));
    }

    @Test
    void cargarAdminLocalConFormatoInvalido() {
        Inventario inventario = new Inventario();
        assertThrows(NumberFormatException.class, () -> inventario.cargarAdminsLocales("data/archivoAdminLocal_invalido.txt"));
    }

    @Test
    void cargarProductoConArchivoInexistente() {
        Inventario inventario = new Inventario();
        assertThrows(IOException.class, () -> inventario.cargarProductos("archivo_inexistente.txt"));
    }

    @Test
    void cargarProductoConFormatoInvalido() {
        Inventario inventario = new Inventario();
        assertThrows(NumberFormatException.class, () -> inventario.cargarProductos("data/archivoProductos_invalido.txt"));
    }

    @Test
    void cargarUsuarioConArchivoInexistente() {
        Inventario inventario = new Inventario();
        assertThrows(IOException.class, () -> inventario.cargarUsuarios("archivo_inexistente.txt"));
    }

    @Test
    void cargarUsuarioConFormatoInvalido() {
        Inventario inventario = new Inventario();
        assertThrows(NumberFormatException.class, () -> inventario.cargarUsuarios("data/archivoUsuarios_invalido.txt"));
    }

    @Test
    void cargarVentaConArchivoInexistente() {
        Inventario inventario = new Inventario();
        assertThrows(IOException.class, () -> inventario.cargarVentas("archivo_inexistente.txt"));
    }

    @Test
    void cargarVentaConFormatoInvalido() {
        Inventario inventario = new Inventario();
        assertThrows(NumberFormatException.class, () -> inventario.cargarVentas("data/archivoVentas_invalido.txt"));
    }

}
