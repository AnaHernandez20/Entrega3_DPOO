package test;

import static org.junit.Assert.*;
import org.junit.Test;

import Programa.Tarifa;

public class TarifaTest {

    @Test
    public void testCrearTarifaSinDescuento() {
        // Crear una tarifa sin descuento
        Tarifa tarifa = new Tarifa(5, true, 1, 100.0, 50.0);

        // Verificar que los valores se han configurado correctamente
        assertEquals(5, tarifa.getDiasRenta());
        assertEquals(1, tarifa.getNumeroConductoresExtra());
        assertEquals(100.0, tarifa.getTarifaDiariaNormal(), 0.001);
        assertEquals(50.0, tarifa.getPrecioSeguros(), 0.001);
        assertFalse(tarifa.getPrecioTotal() == 0.0);  // Asegurarse de que el precio total no sea cero
    }

    @Test
    public void testCrearTarifaConDescuento() {
        // Crear una tarifa con descuento
        Tarifa tarifa = new Tarifa(7, false, 2, 120.0, 60.0, true);

        // Verificar que los valores se han configurado correctamente
        assertEquals(7, tarifa.getDiasRenta());
        assertEquals(2, tarifa.getNumeroConductoresExtra());
        assertEquals(120.0, tarifa.getTarifaDiariaNormal(), 0.001);
        assertEquals(60.0, tarifa.getPrecioSeguros(), 0.001);
        assertTrue(tarifa.getPrecioTotal() < 0.9 * (7 * 120.0 + 60.0 + 2000 * 2));  // Asegurarse de que hay descuento
    }

    @Test
    public void testModificarDiasRenta() {
        // Crear una tarifa y modificar los días de renta
        Tarifa tarifa = new Tarifa(5, true, 1, 100.0, 50.0);
        tarifa.setDiasRenta(3);

        // Verificar que los días de renta se han actualizado correctamente
        assertEquals(3, tarifa.getDiasRenta());
        assertTrue(tarifa.getPrecioTotal() < 5 * 100.0);  // Asegurarse de que el precio total se ha ajustado
    }

    @Test
    public void testModificarNumeroConductoresExtra() {
        // Crear una tarifa y modificar el número de conductores extra
        Tarifa tarifa = new Tarifa(5, true, 1, 100.0, 50.0);
        tarifa.setNumeroConductoresExtra(2);

        // Verificar que el número de conductores extra se ha actualizado correctamente
        assertEquals(2, tarifa.getNumeroConductoresExtra());
        assertTrue(tarifa.getPrecioTotal() > 5 * 100.0);  // Asegurarse de que el precio total se ha ajustado
    }

    // Agrega más pruebas según sea necesario.

}
