package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class ManejadorSesionesTest {

    private ManejadorSesiones manejadorSesiones;

    @Before
    public void setUp() throws Exception {
        manejadorSesiones = new ManejadorSesiones();
    }

    @Test
    public void testCargarUsuarios() throws Exception {
        // Verifica que la lista de usuarios se cargue correctamente desde el archivo
        assertEquals(10, manejadorSesiones.getUsers().size());
    }

    @Test
    public void testRevisarUsuarioExistenteConContraseñaCorrecta() {
        // Verifica que un usuario existente con contraseña correcta devuelve el rol
        assertEquals("adminLocal", manejadorSesiones.revisarUsuario("usuario2", "contrasena2""));
    }

    @Test
    public void testRevisarUsuarioExistenteConContraseñaIncorrecta() {
        // Verifica que un usuario existente con contraseña incorrecta devuelve mensaje de error
        assertEquals("Mi bro te equivocaste de contrasena", manejadorSesiones.revisarUsuario("usuario4", "contrasenaIncorrecta"));
    }

    @Test
    public void testRevisarUsuarioNoExistente() {
        // Verifica que un usuario no existente devuelve mensaje de error
        assertEquals("Usuario no existe", manejadorSesiones.revisarUsuario("usuarioxd", "contrasenaxd"));
    }

    @Test
    public void testRevisarUsuarioExistenteConContraseñaCorrectaDevuelveRol() {
        // Verifica que un usuario existente con contraseña correcta devuelve el rol
        assertEquals("cliente", manejadorSesiones.revisarUsuario("usuario1", "contrasena1"));
    }
    
    

}
