package test;

import Programa.Empresa;
import Programa.Inventario;
import Programa.LicenciaConduccion;
import Programa.Reserva;
import Programa.Seguro;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class EmpresaTest {

    @Test
    void testNuevaReservaintegral() {
        try {
            // Crear una instancia de la empresa
            Empresa empresa = new Empresa();

            // Definir datos de prueba
            String categoria = "CategoriaPrueba";
            int indexSedeInicial = 0;
            int indexSedeFinal = 1;
            String loginCliente = "ClientePrueba";
            String fechaInicio = "01/01/2023";
            String fechaFinal = "03/01/2023";
            LocalTime horaInicio = LocalTime.now();
            LocalTime horaFinal = LocalTime.now();
            LocalDate fechaInicioDate = LocalDate.parse(fechaInicio, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            LocalDate fechaFinalDate = LocalDate.parse(fechaFinal, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            LicenciaConduccion licenciaCliente = new LicenciaConduccion(12345, "Pais", LocalDate.now().plusDays(30), "URL");
            int numConductoresExtra = 1;
            boolean descuento = true;

            // Agregar un seguro de prueba
            Seguro seguroPrueba = new Seguro("SeguroPrueba", 10.0);
            empresa.getseguros().add(seguroPrueba);

            // Realizar nueva reserva
            Reserva nuevaReserva = empresa.nuevaReserva(categoria, indexSedeInicial, indexSedeFinal, loginCliente, fechaInicio,
                    fechaFinal, horaInicio, horaFinal, fechaInicioDate, fechaFinalDate, licenciaCliente, numConductoresExtra, descuento);

            // Verificar que la reserva se haya creado correctamente
            assertNotNull(nuevaReserva);
            assertEquals(categoria, nuevaReserva.getCategoria().getNombre());
            assertEquals(loginCliente, nuevaReserva.getCliente().getLogin());
            assertEquals(numConductoresExtra, nuevaReserva.getTarifa().getNumeroConductoresExtra());
            assertTrue(empresa.getseguros().contains(seguroPrueba)); // Verificar que el seguro esté presente

            // Agrega más aserciones según la estructura de tu sistema
        } catch (IOException e) {
            fail("Excepción durante la prueba: " + e.getMessage());
        }
    }

    @Test
    void testModificarSegurosReserva() {
        try {
            Empresa empresa = new Empresa();
            // Datos de prueba
            String categoria = "categoriaPrueba";
            int indexSedeInicial = 0;
            int indexSedeFinal = 1;
            String loginCliente = "usuarioPrueba";
            String fechaInicio = "01/01/2023";
            String fechaFinal = "03/01/2023";
            LocalTime horaInicio = LocalTime.of(10, 0);
            LocalTime horaFinal = LocalTime.of(15, 0);
            LocalDate fechaInicioDate = LocalDate.parse(fechaInicio, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            LocalDate fechaFinalDate = LocalDate.parse(fechaFinal, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            LicenciaConduccion licenciaCliente = new LicenciaConduccion(123456, "PaisLicencia", LocalDate.now().plusYears(1), "imagenLicencia");
            int numConductoresExtra = 1;
            boolean descuento = true;

            Reserva reservaPrueba = empresa.nuevaReserva(categoria, indexSedeInicial, indexSedeFinal, loginCliente, fechaInicio, fechaFinal, horaInicio, horaFinal, fechaInicioDate, fechaFinalDate, licenciaCliente, numConductoresExtra, descuento);

            int indiceSeguro1 = 0;
            int indiceSeguro2 = 1;
            empresa.modificarSegurosReserva(indiceSeguro1);
            empresa.modificarSegurosReserva(indiceSeguro2);

            ArrayList<Seguro> segurosReserva = reservaPrueba.getSegurosTomados();

            assertEquals(2, segurosReserva.size());
            // Asegúrate de verificar que los seguros correctos estén presentes en la lista.

            // Repetir el proceso con diferentes conjuntos de datos de prueba.

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

