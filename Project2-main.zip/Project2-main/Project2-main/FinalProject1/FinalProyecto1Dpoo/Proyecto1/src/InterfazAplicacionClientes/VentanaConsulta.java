package InterfazAplicacionClientes;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Programa.Empresa;
import Programa.Sede;
import Programa.Vehiculo;
import Programa.VehiculoAlquilado;
import Programa.VehiculoNoAlquilado;
import Programa.VehiculoNoAlquilado.Estado;

public class VentanaConsulta extends JFrame implements ActionListener{
	
	private JPanel todoPanel;
	private Color miVerde;
	private JComboBox<String> comboBoxSedes;
	private ButtonGroup grupoAccion;
	
	private ArrayList<Sede> misSedes;
	private ArrayList<String> nombresSedes = new ArrayList<String>();
	private String[] nombresSedesEnArreglo;
	private Empresa empresa;
	private String sedeSeleccionada;
	private String fechaInicio;
	private String fechaFinal;
	
	private JTextField fechaInicioField;
	private JTextField fechafinalField;
	private int contadorMamado;
	
	public VentanaConsulta() throws IOException {
		empresa = new Empresa();
		misSedes = empresa.getInventario().getSedes();
		
		for(Sede sedecita: misSedes) {
			nombresSedes.add(sedecita.getNombre());
		}
		
		//Casteo mi lista 
		
		nombresSedesEnArreglo = nombresSedes.toArray(new String[0]);
				
		//COMBOBOXX!
		comboBoxSedes = new JComboBox<>(nombresSedesEnArreglo);
		
		//Quiero crear un color
		miVerde = new Color(202,222,185);
				
		//Quiero un panel grande con MINIpaneles
		todoPanel = new JPanel(new BorderLayout());
		todoPanel.setBackground(Color.white);
				
		//Minipanel de arriba que es un BorderLayout
		JPanel panelArriba = new JPanel(new BorderLayout());
		panelArriba.setBackground(miVerde);
		panelArriba.setPreferredSize(new Dimension(800, 90));
				
		//Etiqueta del titulo centrada en un panel de BorderLayout
		JLabel etiquetaRapidos = new JLabel("Rápidos y Aletosos", JLabel.CENTER);
		etiquetaRapidos.setFont(new Font("Georgia", Font.BOLD, 40));
		panelArriba.add(etiquetaRapidos, BorderLayout.CENTER);
				
		//Minipanel de abajo que es un Border Layout
		JPanel panelAbajo = new JPanel(new BorderLayout());
				
		//Configuracion del boton de enviar
		JButton botonEnviar = new JButton("Enviar");
		botonEnviar.setFont(new Font("Georgia", Font.PLAIN, 16));
		botonEnviar.setForeground(Color.BLACK);
		botonEnviar.setBackground(miVerde);
		botonEnviar.setPreferredSize(new Dimension(40, 50));
		panelAbajo.add(botonEnviar, BorderLayout.CENTER);
		
		
		//Minipanel de la mitad que es un 
		JPanel panelMitad = new JPanel();
		JLabel instruccioneseEtiqueta = new JLabel("Elije el nombre de la sede a consultar y el rango de fechas ");
		
		//Decorar fuentes
		instruccioneseEtiqueta.setFont(new Font("Georgia", Font.PLAIN, 17));
		comboBoxSedes.setFont(new Font("Georgia", Font.PLAIN, 14));
		comboBoxSedes.setBorder(BorderFactory.createLineBorder(miVerde, 2));
		
		
		panelMitad.setSize(500, 600);
		panelMitad.setLayout(null);
		
		
		// Establecer las posiciones y tamaños de las etiquetas y campos de texto
		instruccioneseEtiqueta.setBounds(10, 20, 470, 40); // x, y, width, height
		comboBoxSedes.setBounds(30,70,90,30);
		
		
		
		panelMitad.add(instruccioneseEtiqueta);
		panelMitad.add(comboBoxSedes);
		
		JLabel primerafechaLabel = new JLabel("Fecha de inicio (DD/MM/AA)");
		fechaInicioField = new JTextField(20);
		fechaInicioField.setMaximumSize(new Dimension(300, 70));
		
		primerafechaLabel.setBounds(30, 100, 470, 40);
		fechaInicioField.setBounds(190, 105, 90, 30);
		
		panelMitad.add(primerafechaLabel);
		panelMitad.add(fechaInicioField);
		
		JLabel ultimaFechaLabel = new JLabel("Fecha final (DD/MM/AA)");
		fechafinalField = new JTextField(20);
		fechafinalField.setMaximumSize(new Dimension(300, 70));
	
		ultimaFechaLabel.setBounds(30, 150, 470, 40);
		fechafinalField.setBounds(190, 155, 90, 30);
		
		panelMitad.add(ultimaFechaLabel);
		panelMitad.add(fechafinalField);
		
		
		//Ahora añado el formulario al panel mitad
		todoPanel.add(panelArriba, BorderLayout.NORTH);
		todoPanel.add(panelMitad, BorderLayout.CENTER);
		todoPanel.add(panelAbajo, BorderLayout.SOUTH);

		
		//ActionListenerEnviar
		botonEnviar.setActionCommand("Enviar");
		botonEnviar.addActionListener(this);
				
		
		//Agrega el panel con todos los minipaneles que acabo de crear a la ventana
		setContentPane(todoPanel);
			
		//Detiene la aplicación al cerrar la ventana
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
		//Define el tamaño inicial de la ventana
		setSize(800, 550);
		setResizable(false);
				
		//Define el título de la ventana
		setTitle("AdministradorGeneral");
	
		//Muestra la ventana
		setVisible(true);
	}
	
	// Función para verificar si una fecha está dentro de un rango
    private static boolean estaEnRango(LocalDate fechaAVerificar, LocalDate fechaInicio, LocalDate fechaFin) {
        return !fechaAVerificar.isBefore(fechaInicio) && !fechaAVerificar.isAfter(fechaFin);
    }
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String grito = e.getActionCommand();
		
		if (grito.equals("Enviar")) {
			sedeSeleccionada = (String) comboBoxSedes.getSelectedItem();
			fechaInicio = fechaInicioField.getText();
			fechaFinal = fechafinalField.getText();
			contadorMamado = 0;
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate fechaIncioDate = LocalDate.parse(fechaInicio, formatter);
			LocalDate fechaFinalDate = LocalDate.parse(fechaFinal, formatter);
			
			
			 //System.out.println(empleadoSeleccionado);
			 
			 int indice = 0;
			 boolean checker = false;
			 Sede sedeObjeto = null;
			 
			 while (indice < misSedes.size() && checker == false) {
		         if (misSedes.get(indice).getNombre().equalsIgnoreCase(sedeSeleccionada)) {
		        	 sedeObjeto = misSedes.get(indice);
		        	 checker = true;
		         }
				 indice++;
		        }
			 
			 for (VehiculoNoAlquilado vehiculazo: empresa.getInventario().getVehiculosNoAlquilados()) {
				 
				 LocalDate fechaVerificar = vehiculazo.getFechaRegreso();
				 Sede sedeVerificar = vehiculazo.getSedeUbicacion();
				 String nombreSedeVerificar = sedeVerificar.getNombre();
				 
				 if ((estaEnRango(fechaVerificar, fechaIncioDate, fechaFinalDate) && nombreSedeVerificar.equals(sedeSeleccionada)) || (vehiculazo.getEstado().equals(Estado.DISPONIBLE))) {
					 contadorMamado++;
				 }
			 }
			 
			 for (VehiculoAlquilado vehiculazo: empresa.getInventario().getVehiculosAlquilados()) {
				 LocalDate fechaVerificar = vehiculazo.getFechaDevolucion();
				 Sede sedeVerificar = vehiculazo.getSedeDevolucion();
				 String nombreSedeVerificar = sedeVerificar.getNombre();
				 
				 if (estaEnRango(fechaVerificar, fechaIncioDate, fechaFinalDate) && nombreSedeVerificar.equals(sedeSeleccionada)) {
					 contadorMamado++;
				 }
			 }
			 
			 
			 JOptionPane.showMessageDialog(null, "Hay "+contadorMamado+" carros disponibles en la sede "+sedeSeleccionada+" en ese rango de fechas.");
			 
			 
		}
		
		
		
	}

}
