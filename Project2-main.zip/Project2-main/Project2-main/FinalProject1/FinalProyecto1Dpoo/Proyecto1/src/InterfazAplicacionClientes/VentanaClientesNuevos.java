package InterfazAplicacionClientes;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class VentanaClientesNuevos extends JFrame implements ActionListener{
	
	private JPanel todoPanel;
	private Color miVerde;
	
	private String usuario;
	private String contrasena;
	private String nombre;
	private String correo;
	private String telefono;
	private String fechaNacimiento;
	
	
	private VentanaClientesNuevos2 ventanitaAparte;
	
	private JTextField usuarioField;
	private JTextField contrasenaField;
	private JTextField nombreField;
	private JTextField correoField;
	private JTextField telefonoField;
	private JTextField fechaNacimientoField;
	
	

	public VentanaClientesNuevos() {
		
		//Quiero crear un color
		miVerde = new Color(202,222,185);
		
		//Quiero un panel grande con MINIpaneles
		todoPanel = new JPanel(new BorderLayout());
		todoPanel.setBackground(Color.white);
		
		//Minipanel de arriba que es un BorderLayout
		JPanel panelArriba = new JPanel(new BorderLayout());
		panelArriba.setBackground(miVerde);
		panelArriba.setPreferredSize(new Dimension(800, 90));
		
		//Etiqueta del titulo centrada en un panel de BorderLayout
		JLabel etiquetaRapidos = new JLabel("Rápidos y Aletosos", JLabel.CENTER);
		etiquetaRapidos.setFont(new Font("Georgia", Font.BOLD, 40));
		panelArriba.add(etiquetaRapidos, BorderLayout.CENTER);
		
		//Minipanel de abajo que es un Border Layout
		JPanel panelAbajo = new JPanel(new BorderLayout());
		
		//Configuracion del boton de enviar
		JButton botonEnviar = new JButton("Siguiente");
		botonEnviar.setFont(new Font("Georgia", Font.PLAIN, 16));
		botonEnviar.setForeground(Color.BLACK);
		botonEnviar.setBackground(miVerde);
		botonEnviar.setPreferredSize(new Dimension(40, 50));
		panelAbajo.add(botonEnviar, BorderLayout.CENTER);
		
		
		//Minipanel de la mitad que es un Border Layout
		JPanel panelMitad = new JPanel(new BorderLayout());
		panelMitad.setBackground(Color.white);
		
		
		//Lema de la empresa que va al norte en la mitad
		JLabel etiquetaLema = new JLabel("La carretera te llama, nosotros te equipamos", JLabel.CENTER);
		etiquetaLema.setFont(new Font("Georgia", Font.PLAIN, 30));
		panelMitad.add(etiquetaLema, BorderLayout.NORTH);
		
		
		//JPanel para ubicar con el menu y las cosas
		JPanel panelMensaje= new JPanel(new BorderLayout());
		
		//Instruccion
		JLabel etiquetaInstruccion = new JLabel("Ingrese su informacion", JLabel.CENTER);
		etiquetaInstruccion.setFont(new Font("Georgia", Font.PLAIN, 20));
		
		//Opciones en un JPanel en Grid
				
		JPanel panelMenuInfoBasica = new JPanel(new GridLayout(6, 1));
		
		JLabel usuarioLabel = new JLabel("Usuario");
		usuarioField = new JTextField(20);
		usuarioField.setMaximumSize(new Dimension(300, 70));
		JLabel contrasenaLabel = new JLabel("Contraseña");
		contrasenaField = new JTextField(20);
		contrasenaField.setMaximumSize(new Dimension(300, 70));
		
		JLabel nombreLabel = new JLabel("Nombre");
		nombreField = new JTextField(20);
		nombreField.setMaximumSize(new Dimension(300, 70));
		JLabel correoLabel = new JLabel("Correo");
		correoField = new JTextField(20);
		correoField.setMaximumSize(new Dimension(300, 70));
		JLabel telefonoLabel = new JLabel("Telefono");
		telefonoField = new JTextField(20);
		telefonoField.setMaximumSize(new Dimension(300, 70));
		JLabel fechaNacimientoLabel = new JLabel("Fecha Nacimiento DD/MM/AAAA");
		fechaNacimientoField= new JTextField(20);
		fechaNacimientoField.setMaximumSize(new Dimension(300, 70));
		
		//Fuentes
	
		usuarioLabel.setFont(new Font("Georgia", Font.BOLD, 20));

		contrasenaLabel.setFont(new Font("Georgia", Font.BOLD, 20));
		nombreLabel.setFont(new Font("Georgia", Font.BOLD, 20));
		telefonoLabel.setFont(new Font("Georgia", Font.BOLD, 20));
		correoLabel.setFont(new Font("Georgia", Font.BOLD, 20));
		fechaNacimientoLabel.setFont(new Font("Georgia", Font.BOLD, 20));
		//ActionListenerEnviar
		botonEnviar.setActionCommand("Siguiente");
		botonEnviar.addActionListener(this);
		
		//Añadimos todo
		panelMensaje.setBackground(Color.white);
		panelMenuInfoBasica.setBackground(Color.white);
		panelMensaje.add(etiquetaInstruccion);
		panelMenuInfoBasica.add(usuarioLabel);
		panelMenuInfoBasica.add(usuarioField);
		panelMenuInfoBasica.add(contrasenaLabel);
		panelMenuInfoBasica.add(contrasenaField);
		panelMenuInfoBasica.add(nombreLabel);
		panelMenuInfoBasica.add(nombreField);
		panelMenuInfoBasica.add(telefonoLabel);
		panelMenuInfoBasica.add(telefonoField);
		panelMenuInfoBasica.add(correoLabel);
		panelMenuInfoBasica.add(correoField);
		panelMenuInfoBasica.add(fechaNacimientoLabel);
		panelMenuInfoBasica.add(fechaNacimientoField);
		
		panelMitad.add(panelMensaje, BorderLayout.CENTER);
		panelMitad.add(panelMenuInfoBasica, BorderLayout.SOUTH);
		
		todoPanel.add(panelArriba, BorderLayout.NORTH);
		todoPanel.add(panelMitad, BorderLayout.CENTER);
		todoPanel.add(panelAbajo, BorderLayout.SOUTH);

		
		//Agrega el panel con todos los minipaneles que acabo de crear a la ventana
		setContentPane(todoPanel);
		
		//Detiene la aplicación al cerrar la ventana
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Define el tamaño inicial de la ventana
		setSize(800, 500);
		setResizable(false);
		
		//Define el título de la ventana
		setTitle("Clientes nuevos");

		//Muestra la ventana
		setVisible(true);
		
		
	}
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String grito = e.getActionCommand();
		usuario = usuarioField.getText();
		contrasena = contrasenaField.getText();
		nombre = nombreField.getText();
		correo = correoField.getText();
		telefono = telefonoField.getText();
		fechaNacimiento = fechaNacimientoField.getText();
		
		
		if (grito.equals("Siguiente")) {
			this.ventanitaAparte = new VentanaClientesNuevos2(usuario, contrasena, nombre, correo, telefono, fechaNacimiento);
			this.dispose();
		}
		
	}
	
}
