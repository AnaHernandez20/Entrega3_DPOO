/**
 * 
 */
/**
 * 
 */
module Proyecto1 {
	requires java.desktop;
	requires jcalendar;
	requires java.base;
}