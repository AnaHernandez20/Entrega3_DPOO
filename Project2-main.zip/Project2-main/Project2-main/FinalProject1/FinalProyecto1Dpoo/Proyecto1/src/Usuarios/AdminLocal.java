package Usuarios;

public class AdminLocal extends UsuarioGenerico{
	
	public AdminLocal(String login, String password, String nombre, String rol) {
		super(login, password, nombre, rol);
	}
	
}
