package Usuarios;

public class AdminGeneral extends UsuarioGenerico{

	public AdminGeneral(String login, String password, String nombre, String rol) {
		super(login, password, nombre, rol);
		// TODO Auto-generated constructor stub
	}

}
